import mysql.connector
import serial

if __name__ == '__main__':
    ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
    ser.flush()
    serB = serial.Serial('/dev/serial0', 9600, timeout=1)
    serB.flush()

mydb = mysql.connector.connect(
    host="localhost",
    user="comparisonUser",
    password="raspberry",
    database="ComparisonApp"
    )

mycursor = mydb.cursor()
while True:
        if ser.in_waiting > 0 and serB.in_waiting > 0:
            line = ser.readline().decode('utf-8').rstrip()
            temperature_dataA = float(line)
            sql = "INSERT INTO Arduino_temperature(Arduino_temp_data) VALUES (%s)"%(temperature_dataA)
            mycursor.execute(sql)

            lineB = serB.readline().decode('utf-8').rstrip()
            temperature_dataB = float(lineB)
            sqlB = "INSERT INTO Raspi_temperature(RasPi_temp_data) VALUES (%s)"%(temperature_dataB)
            mycursor.execute(sqlB)
            mydb.commit()




