#!/usr/local/bin/python

import serial
import time
import RPi.GPIO as GPIO

ser = serial.Serial(
port = '/dev/serial0',\
baudrate = 9600, \
bytesize = serial.EIGHTBITS, \
timeout = 1)

GPIO.setmode(GPIO.BCM)

#define the pin that goes to the circuit
pin_to_circuit = 19

def rc_time (pin_to_circuit):
    count = 0
  
    #Output on the pin for 
    GPIO.setup(pin_to_circuit, GPIO.OUT)
    GPIO.output(pin_to_circuit, GPIO.LOW)
    time.sleep(1)

    #Change the pin back to input
    GPIO.setup(pin_to_circuit, GPIO.IN)
  
    #Count until the pin goes high
    while (GPIO.input(pin_to_circuit) == GPIO.LOW):
        count += 1
        if count > 1023: #To reduce the high spicks of data reading divide the sensor reading by half when it reaches a certain threshold
            count = count/2
            count += 1
    return count

#Catch when script is interrupted, cleanup correctly
try:
    # Main loop
    while True:
        tx = ser.write(str.encode("%d")%(rc_time(pin_to_circuit)))
        print(int(rc_time(pin_to_circuit)))
        time.sleep(14) # TIME DELAY 14 + 1 above = 15 seconds
except KeyboardInterrupt:
    pass
finally:
    GPIO.cleanup()
ser.close()

