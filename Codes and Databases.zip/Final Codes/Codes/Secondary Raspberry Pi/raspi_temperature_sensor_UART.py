import Adafruit_DHT
import time
import serial

ser = serial.Serial(
port = '/dev/serial0',\
baudrate = 9600, \
bytesize = serial.EIGHTBITS, \
timeout = 1)

DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 11
 
while True:
    humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
    if humidity is not None and temperature is not None:
          tx = ser.write(str.encode("%f")%(temperature))
          print(temperature)

    time.sleep(14); # TIME DELAY of 15 seconds
   
ser.close()

